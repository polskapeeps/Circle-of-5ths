# Circle of Fifths Electron Icon Pack v2

Fresh repack of the icon assets for Electron.

## Included

- `build/icon.icns` for macOS
- `build/icon.ico` for Windows
- `build/icon.png` master PNG (1024x1024)
- `build/linux/*.png` common Linux sizes
- `build/web/*` favicon and web app sizes
- `source/icon-source.svg` editable vector source
- `source/icon-master-1024.png` master render
- `preview/icon-preview-sheet.png` preview sheet

## electron-builder example

```json
{
  "build": {
    "icon": "build/icon.png",
    "mac": { "icon": "build/icon.icns" },
    "win": { "icon": "build/icon.ico" },
    "linux": { "icon": "build/linux" }
  }
}
```
